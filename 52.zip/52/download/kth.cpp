#include "kth.h"

int query_kth(int n_a, int n_b, int n_c, int k)
{
	return 233;
}
