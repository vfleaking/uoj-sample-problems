#include "uoj_judger.h"

struct MessagePointInfo {
    int scr;
    string info_str;
    
    PointInfo encode_info;
    bool decoded;
    PointInfo decode_info;
    
    MessagePointInfo(const PointInfo &_encode_info)
        : encode_info(_encode_info), decoded(false), decode_info(_encode_info) {
        scr = encode_info.scr;
        info_str = encode_info.info;
    }
    MessagePointInfo(const PointInfo &_encode_info, const PointInfo &_decode_info)
        : encode_info(_encode_info), decoded(true), decode_info(_decode_info) {
        if (decode_info.scr != 100) {
	        scr = decode_info.scr;
	        info_str = decode_info.info;
	    } else {
        	scr = encode_info.scr;
	        info_str = encode_info.info;
	    }
    }
};

void add_point_info(const MessagePointInfo &info) {
    if (!info.decoded) {
        add_point_info(info.encode_info);
        return;
    }
       
    PointInfo encode_info = info.encode_info, decode_info = info.decode_info;
	
	int ust = -1, usm = -1;
	if (encode_info.ust >= 0 && decode_info.ust >= 0) {
        ust = encode_info.ust + decode_info.ust;
    }
	if (encode_info.usm >= 0 && decode_info.usm >= 0) {
	    usm = max(encode_info.usm, decode_info.usm);
	}
	
	if (encode_info.num >= 0) {
	    if (ust != -1) {
	        tot_time += ust;
	    }
	    if (usm != -1) {
	        max_memory = max(max_memory, usm);
	    }
	}
	
	tot_score += info.scr;

	details_out << "<test num=\"" << encode_info.num << "\""
		<< " score=\"" << info.scr << "\""
		<< " info=\"" << htmlspecialchars(info.info_str) << "\""
		<< " time=\"" << ust << "\""
		<< " memory=\"" << usm << "\">" << endl;
	details_out << "<in>" << htmlspecialchars(encode_info.in) << "</in>" << endl;
	details_out << "<out>" << htmlspecialchars(encode_info.out) << "</out>" << endl;
	details_out << "<res>" << htmlspecialchars(encode_info.res) << "</res>" << endl;
	details_out << "<in>" << htmlspecialchars(decode_info.in) << "</in>" << endl;
	details_out << "<out>" << htmlspecialchars(decode_info.out) << "</out>" << endl;
	details_out << "<res>" << htmlspecialchars(decode_info.res) << "</res>" << endl;
	details_out << "</test>" << endl;
}

RunResult run_send(const string &input_file_name, const string &output_file_name) {
	string program_type = "default";
	return run_program(
			(result_path + "/run_send_program.txt").c_str(),
			input_file_name.c_str(),
			output_file_name.c_str(),
			"/dev/null",
			RL_CHECKER_DEFAULT,
			("--type=" + program_type).c_str(),
			(data_path + "/" + "send").c_str(),
			NULL);
}
RunCheckerResult run_transport(const string &input_file_name, const string &transport_file_name, const string &output_file_name) {
	RunResult ret = run_program(
			(string(result_path) + "/run_transport_result.txt").c_str(),
			"/dev/null",
			output_file_name.c_str(),
			(string(result_path) + "/transport_error.txt").c_str(),
			RL_CHECKER_DEFAULT,
			("--add-readable=" + input_file_name).c_str(),
			("--add-readable=" + transport_file_name).c_str(),
			(data_path + "/" + "transport").c_str(),
			realpath(input_file_name).c_str(),
			realpath(transport_file_name).c_str(),
			realpath(transport_file_name).c_str(),
			NULL);
	
	RunCheckerResult res;
	res.type = ret.type;
	res.ust = ret.ust;
	res.usm = ret.usm;

	if (ret.type != runp::RS_AC) {
		res.scr = 0;
	} else {
		FILE *fres = fopen((result_path + "/transport_error.txt").c_str(), "r");
		char type[21];
		if (fres == NULL || fscanf(fres, "%20s", type) != 1) {
			return RunCheckerResult::failed_result();
		}
		if (strcmp(type, "ok") == 0) {
			res.scr = 100;
		} else if (strcmp(type, "points") == 0) {
			double d;
			if (fscanf(fres, "%lf", &d) != 1) {
				return RunCheckerResult::failed_result();
			} else {
				res.scr = (int)floor(100 * d + 0.5);
			}
		} else {
			res.scr = 0;
		}
		fclose(fres);
	}
	res.info = file_preview(result_path + "/transport_error.txt");
	return res;
}

MessagePointInfo message_test_point(string name, const int &num, TestPointConfig tpc = TestPointConfig()) {
	tpc.auto_complete(num);
	
	string send_file_name = work_path + "/" + "send.txt";
	string transport_input_file_name = work_path + "/" + "transport.in";
	string transport_output_file_name = work_path + "/" + "transport.out";
	
	if (run_send(tpc.input_file_name, send_file_name).type != runp::RS_AC) {
		end_judge_judgement_failed("Judgment Failed");
	}

	RunResult encode_ret = run_submission_program(
				send_file_name,
				transport_input_file_name,
				conf_run_limit(num, RL_DEFAULT),
				name);
	if (encode_ret.type != runp::RS_AC) {
		return MessagePointInfo(PointInfo(num, 0, -1, -1,
				info_str(encode_ret.type),
				file_preview(send_file_name), file_preview(transport_input_file_name),
				""));
	}
	
	RunCheckerResult transport_ret = run_transport(
	        tpc.input_file_name,
			transport_input_file_name,
			transport_output_file_name);
	if (transport_ret.type != runp::RS_AC) {
		end_judge_judgement_failed("Judgment Failed");
	}
	
	string encode_info_str;
	if (transport_ret.scr == 0) {
		encode_info_str = "Wrong Answer";
	} else if (transport_ret.scr == 100) {
		encode_info_str = "Accepted";
	} else {
		encode_info_str = "Acceptable Answer";
	}
	
	PointInfo encode_info(num, transport_ret.scr, encode_ret.ust, encode_ret.usm, 
			encode_info_str,
			file_preview(send_file_name), file_preview(transport_input_file_name),
			transport_ret.info);
	
	if (transport_ret.scr == 0) {
	    return MessagePointInfo(encode_info);
	}
	
	RunResult decode_ret = run_submission_program(
				transport_output_file_name,
				tpc.output_file_name,
				conf_run_limit(num, RL_DEFAULT),
				name);
	if (decode_ret.type != runp::RS_AC) {
		return MessagePointInfo(encode_info, PointInfo(num, 0, -1, -1,
				info_str(decode_ret.type),
				file_preview(transport_output_file_name), file_preview(tpc.output_file_name),
				""));
	}
	
	RunCheckerResult chk_ret = run_checker(
			conf_run_limit("checker", num, RL_CHECKER_DEFAULT),
			conf_str("checker"),
			tpc.input_file_name,
			tpc.output_file_name,
			tpc.answer_file_name);
	if (chk_ret.type != runp::RS_AC) {
	    end_judge_judgement_failed("Judgment Failed");
	}
	
	string decode_info_str;
	if (chk_ret.scr == 0) {
		decode_info_str = "Wrong Answer";
	} else if (chk_ret.scr == 100) {
		decode_info_str = "Accepted";
	} else {
		decode_info_str = "Acceptable Answer";
	}
	
	PointInfo decode_info(num, chk_ret.scr, decode_ret.ust, decode_ret.usm, 
			decode_info_str,
			file_preview(transport_output_file_name), file_preview(tpc.output_file_name),
			chk_ret.info);
	
	return MessagePointInfo(encode_info, decode_info);
}

void ordinary_test() {
    int n = conf_int("n_tests", 10);
	int m = conf_int("n_ex_tests", 0);
	
	report_judge_status_f("Compiling");
	RunCompilerResult c_ret = compile("answer");
	if (!c_ret.succeeded) {
		end_judge_compile_error(c_ret);
	}
    
    bool passed = true;
    for (int i = 1; i <= n; i++) {
		report_judge_status_f("Judging Test #%d", i);
		MessagePointInfo po = message_test_point("answer", i);
		if (po.scr != 100) {
			passed = false;
		}
		po.scr = scale_score(po.scr, conf_int("point_score", i, 100 / n));
		add_point_info(po);
	}
	
	if (passed) {
	    tot_score = 100;
	    for (int i = 1; i <= m; i++) {
		    report_judge_status_f("Judging Extra Test #%d", i);
		    MessagePointInfo po = message_test_point("answer", -i);
		    if (po.scr != 100) {
			    po.encode_info.num = -1;
			    po.info_str = "Extra Test Failed : " + po.info_str + " on " + vtos(i);
			    po.scr = -3;
			    add_point_info(po);
			    end_judge_ok();
		    }
	    }
	    if (m != 0) {
		    PointInfo po(-1, 0, -1, -1, "Extra Test Passed", "", "", "");
		    add_point_info(po);
	    }
	}
	end_judge_ok();
}

void sample_test() {
	report_judge_status_f("Compiling");
    RunCompilerResult c_ret = compile("answer");
	if (!c_ret.succeeded) {
		end_judge_compile_error(c_ret);
	}

	int n = conf_int("n_sample_tests", 0);
	bool passed = true;
	for (int i = 1; i <= n; i++) {
		report_judge_status_f("Judging Sample Test #%d", i);
		MessagePointInfo po = message_test_point("answer", -i);
		po.encode_info.num = i;
	    if (po.scr != 100) {
			passed = false;
		}
		po.scr = scale_score(po.scr, 100 / n);
		add_point_info(po);
	}
	if (passed) {
		tot_score = 100;
	}
	end_judge_ok();
}

int main(int argc, char **argv) {
	judger_init(argc, argv);

	if (conf_is("test_sample_only", "on")) {
		sample_test();
	} else {
		ordinary_test();
	}
	
	return 0;
}
