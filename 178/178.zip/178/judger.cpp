#include "uoj_judger.h"


static int calcT(const vector <int> &us) {
    int ans = 0;
    for (auto i : us) {
        ans = std::max(ans, i);
        if (i == -1) {
            ans = -1;
            break;
        }
    }
    return ans;
}
struct MyPointInfo: public PointInfo {
	vector <int> rust, rusm;
	MyPointInfo(const int &_num, const int &_scr,
			const vector <int> &_ust, const vector <int> &_usm, const string &_info = "default")
			: PointInfo(_num, _scr, calcT(_ust), calcT(_usm), info), rust(_ust), rusm(_usm) {}
	MyPointInfo(const int &_num, const int &_scr,
			const vector <int> &_ust, const vector <int> &_usm, const string &_info,
			const string &_in, const string &_out, const string &_res)
			: PointInfo(_num, _scr, calcT(_ust), calcT(_usm), _info, _in, _out, _res), rust(_ust), rusm(_usm) {}

    string out_time() const {
        ostringstream ans;
        if (rust.size() <= 1) ans << ust;
        else {
            for (int i = 0; i < (int)rust.size(); i++) {
                if (i) ans << "ms,";
                ans << rust[i];
            }
        }
        return ans.str();
    }
    string out_memory() const {
        ostringstream ans;
        if (rusm.size() <= 1) ans << usm;
        else {
            for (int i = 0; i < (int)rusm.size(); i++) {
                if (i) ans << "kb,";
                ans << rusm[i];
            }
        }
        return ans.str();
    }
};


void add_point_info(const MyPointInfo &info, bool update_tot_score = true) {
	if (info.num >= 0) {
		if(info.ust >= 0) {
			tot_time += info.ust;
		}
		if(info.usm >= 0) {
			max_memory = max(max_memory, info.usm);
		}
	}
	if (update_tot_score) {
        tot_score += info.scr;
	}

	details_out << "<test num=\"" << info.num << "\""
		<< " score=\"" << info.scr << "\""
		<< " info=\"" << htmlspecialchars(info.info) << "\""
		<< " time=\"" << info.out_time() << "\""
		<< " memory=\"" << info.out_memory() << "\">" << endl;

	if (!info.use_li) {
		if (conf_str("show_in", "on") == "on") {
			details_out << "<in>" << htmlspecialchars(info.in) << "</in>" << endl;
		}
		if (conf_str("show_out", "on") == "on") {
			details_out << "<out>" << htmlspecialchars(info.out) << "</out>" << endl;
		}
		if (conf_str("show_res", "on") == "on") {
			details_out << "<res>" << htmlspecialchars(info.res) << "</res>" << endl;
		}
	} else {
		for (vector<InfoBlock>::const_iterator it = info.li.begin(); it != info.li.end(); it++) {
			if (it->title == "in" && conf_str("show_in", "on") != "on")
				continue;
			if (it->title == "out" && conf_str("show_out", "on") != "on")
				continue;
			if (it->title == "res" && conf_str("show_res", "on") != "on")
				continue;
			details_out << it->to_str() << endl;
		}
	}
	details_out << "</test>" << endl;
}


void add_subtask_info(const int &num, const int &scr, const string &info, const vector<MyPointInfo> &points) {
	details_out << "<subtask num=\"" << num << "\""
		<< " score=\"" << scr << "\""
		<< " info=\"" << htmlspecialchars(info) << "\">" << endl;
	tot_score += scr;
	for (vector<MyPointInfo>::const_iterator it = points.begin(); it != points.end(); it++) {
		add_point_info(*it, false);
	}
	details_out << "</subtask>" << endl;
}

MyPointInfo my_test_point(int num, TestPointConfig tpc = TestPointConfig()) {
    tpc.auto_complete(num);
    if (tpc.validate_input_before_test) {
		RunValidatorResult val_ret = run_validator(
				tpc.input_file_name,
				conf_run_limit("validator", 0, RL_VALIDATOR_DEFAULT),
				conf_str("validator"));
		if (val_ret.type != runp::RS_AC) {
			return MyPointInfo(num, 0, {-1}, {-1},
					"Validator " + info_str(val_ret.type),
					file_preview(tpc.input_file_name), "",
					"");
		} else if (!val_ret.succeeded) {
			return MyPointInfo(num, 0, {-1}, {-1},
					"Invalid Input",
					file_preview(tpc.input_file_name), "",
					val_ret.info);
		}
	}
    
    string tmpfile = work_path + "/tmpfile";

    RunResult Apro_ret = run_submission_program(
            tpc.input_file_name.c_str(),
            tmpfile.c_str(),
            tpc.limit,
            "Anna");
    if (Apro_ret.type != runp::RS_AC) {
        return MyPointInfo(num, 0, {-1}, {-1},
                info_str(Apro_ret.type),
                file_preview(tpc.input_file_name), "",
                "");
    }


    RunResult Bpro_ret = run_submission_program(
            tmpfile.c_str(),
            tpc.output_file_name.c_str(),
            tpc.limit,
            "Bruno");
    if (Bpro_ret.type != runp::RS_AC) {
        return MyPointInfo(num, 0, {Apro_ret.ust, -1}, {Apro_ret.usm, -1},
                info_str(Bpro_ret.type),
                file_preview(tpc.input_file_name), file_preview(tpc.output_file_name),
                "");
    }

	RunCheckerResult chk_ret = run_checker(
			conf_run_limit("checker", num, RL_CHECKER_DEFAULT),
			tpc.checker,
			tpc.input_file_name,
			tpc.output_file_name,
			"/dev/null");
	if (chk_ret.type != runp::RS_AC) {
		return MyPointInfo(num, 0, {-1}, {-1},
				"Checker " + info_str(chk_ret.type),
				file_preview(tpc.input_file_name), file_preview(tpc.output_file_name),
				"");
	}

    return MyPointInfo(num, chk_ret.scr, {Apro_ret.ust, Bpro_ret.ust}, {Apro_ret.usm, Bpro_ret.usm}, 
            "default",
            file_preview(tpc.input_file_name), file_preview(tpc.output_file_name),
            chk_ret.info);
}


void ordinary_test() {
	primary_data_test([](int i) {
		return (PointInfo)my_test_point(i);
	});
	end_judge_ok();
}

MyPointInfo my_test_hack_point(TestPointConfig tpc) {
	tpc.submit_answer = false;
	tpc.validate_input_before_test = false;
	tpc.auto_complete(0);
	RunValidatorResult val_ret = run_validator(
			tpc.input_file_name,
			conf_run_limit("validator", 0, RL_VALIDATOR_DEFAULT),
			conf_str("validator", "val"));
	if (val_ret.type != runp::RS_AC) {
		return MyPointInfo(0, 0, {-1}, {-1},
				"Validator " + info_str(val_ret.type),
				file_preview(tpc.input_file_name), "",
				"");
	} else if (!val_ret.succeeded) {
		return MyPointInfo(0, 0, {-1}, {-1},
				"Invalid Input",
				file_preview(tpc.input_file_name), "",
				val_ret.info);
	}

	executef("touch %s", tpc.answer_file_name.c_str());

	MyPointInfo po = my_test_point(0, tpc);
	po.scr = po.scr != 100;
	return po;
}
void hack_test() {
	TestPointConfig tpc;
	tpc.input_file_name = work_path + "/hack_input.txt";
	tpc.output_file_name = work_path + "/pro_output.txt";
	tpc.answer_file_name = work_path + "/std_output.txt";

	PointInfo po = my_test_hack_point(tpc);
	add_point_info(po);
	end_judge_ok();
}

void sample_test() {
	sample_data_test([](int i) {
		return test_point("answer", i);
	});
	end_judge_ok();
}

int main(int argc, char **argv) {
	judger_init(argc, argv);

    report_judge_status_f("Compiling Anna");
    RunCompilerResult A_ret = compile_with_implementer("Anna", "implementer_Anna");
    if (!A_ret.succeeded) {
        end_judge_compile_error(A_ret);
    }
    
    report_judge_status_f("Compiling Bruno");
    RunCompilerResult B_ret = compile_with_implementer("Bruno", "implementer_Bruno");
    if (!B_ret.succeeded) {
        end_judge_compile_error(B_ret);
    }

	if (conf_is("test_new_hack_only", "on")) {
		hack_test();
	} else if (conf_is("test_sample_only", "on")) {
		sample_test();
	} else {
		ordinary_test();
	}
}
