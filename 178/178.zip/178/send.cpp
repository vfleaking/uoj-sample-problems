#include <iostream>
#include <cstdio>
using namespace std;

typedef unsigned u32;

const int N = 1024;

int main()
{
	puts("encode");
	for (int i = 0; i < N; i++)
	{
		u32 key, val;
		scanf("%u %u", &key, &val);
		printf("%u %u\n", key, val);
	}
	return 0;
}
