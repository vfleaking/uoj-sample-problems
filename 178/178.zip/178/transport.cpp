#include "testlib.h"
#include <iostream>
using namespace std;

const int N = 1024;

int main(int argc, char **argv)
{
	registerTestlibCmd(argc, argv);

	puts("decode");

	string str = ouf.readString("[01]{0,100000}");
	cout << str << endl;

	for (int i = 0; i < N; i++)
		inf.readLong(), inf.readLong();

	int nT = inf.readInt(1, N, "T");
	cout << nT << endl;
	for (int t = 0; t < nT; t++)
	{
		long long key = inf.readLong();
		cout << key << endl;
	}

	int scr = 0;
	static int w[11] = {0, 100000, 43008, 40000, 30000, 20000, 15000, 14000, 13000, 12750, 12500};
	for (int i = 1; i <= 10; i++)
		if ((int)str.size() <= w[i])
			scr++;
    if (scr == 10) {
    	quitf(_ok, "%d bits", (int)str.size());
    } else {
        quitp((double)scr / 10, "%d bits", (int)str.size());
    }
}
